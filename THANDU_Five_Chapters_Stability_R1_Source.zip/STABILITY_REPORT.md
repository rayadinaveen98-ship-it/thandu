# THANDU — Five-Chapter Android Stability R1

## What was repaired

1. **Single active screen:** a shared chapter lifecycle controller owns Arrival, Memories, Growing Years, Bloom and Joy. Every inactive chapter is `display:none`, `inert`, and `aria-hidden` so old scenes stop painting and cannot intercept touches.
2. **Real navigation:** explicit Next/Back routing, consistent on-screen controls and browser history. An `THANDU_APP_BACK` JavaScript API serves the native Android Back button and closes photo dialogs before changing chapters.
3. **Reliable Memories handoff:** a proper accessible “Growing Years” button is always available on all widths instead of disappearing behind a five-photo unlock at 360px.
4. **Stable bird target:** the input button itself stops moving; the bird artwork moves inside it. Revealing the original photograph still works.
5. **No photo/control collision in Joy:** fixed 320px portrait montage layout and separated party controls from the six photographs; also validated landscape as two-column, scrollable rather than clipping.
6. **Reachable small buttons:** main navigation, photo controls and CTA minimum touch height increased to 44px where practical.
7. **Landscape access:** active scene has a taller document area with normal page scrolling when viewport height is short instead of clipping navigation offscreen.
8. **Streaming Android page loader:** WebView now serves `https://appassets.androidplatform.net/index.html` and `media/*` from APK assets through `shouldInterceptRequest`, avoiding synchronous 7.3MB HTML reading on Android’s main thread. No Internet permission is needed.
9. **Photo fidelity:** 31 embedded image references were extracted into 27 byte-identical original image files (duplicate photos deduplicated), with zero recompression or facial modification. Main HTML dropped from 7,296,898 bytes to 231,794 bytes, while 4,151,095 bytes of local media remain bundled. Exact hashes in `STABILITY_BUILD_MANIFEST.json`.
10. **Device diagnostics:** Android WebChromeClient logs JS console errors, WebViewClient logs missing assets and can recover once from renderer loss. The native Android Back handler calls the chapter/dialog handler and falls back to Android history/exit only when appropriate.
11. **Checkpoint clarity:** Joy’s final button is explicitly marked “End of five-chapter preview” rather than looking like a broken link to an unfinished chapter.

## Browser integration tests

- Chromium **390×844**: 25/25 checks passed, zero JS errors.
- Chromium **320×640**: 25/25 checks passed, zero JS errors.
- Chromium **800×360**: 26/26 checks passed, zero JS errors, landscape scrolling available.
- Chromium **1440×900**: 25/25 checks passed, zero JS errors.

Core checks include: Skip intro; touch bird and reveal photo; 5-chapter forward navigation; photo reveals; previous scenes not being painted; Joy montage; action row vs photo wall no 2D overlap; native-back JS handling; consecutive back navigation; no JS exceptions.

## What still requires actual device verification

- Android WebView install/launch on the user's Android hardware, physical gesture navigation, memory pressure and frame rate.
- Manufacturer-specific fullscreen insets, unusual font settings and screen-reader behavior.
- Joy/Bloom animation cadence under real Android GPU thermal and memory conditions.

**This is a stability update preserving the user-approved designs; not a new creative redesign.**
