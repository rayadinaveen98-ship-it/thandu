/* THANDU Checkpoint R1 — Unified chapter lifecycle, back stack and focus.
 * Visuals, artwork and photograph source pixels are not changed by this module.
 */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const stageIds=['shell','handoff','growStage','bloomStage','joyStage'];
const keys=['arrival','memories','growing','bloom','joy'];
let current=0, navigating=false, motionOff=matchMedia('(prefers-reduced-motion: reduce)').matches;
const root=()=>document.documentElement;
function live(el){return !!el&&!el.hasAttribute('inert');}
function closeDialogs(){
 for(const d of document.querySelectorAll('dialog[open]')){try{d.close()}catch(e){d.removeAttribute('open')}}
}
function keepOne(idx){
 current=idx;document.body.setAttribute('data-thandu-chapter',keys[idx]);
 for(let j=0;j<stageIds.length;j++){
  const s=$(stageIds[j]);if(!s)continue;
  if(j===idx){s.removeAttribute('inert');s.setAttribute('aria-hidden','false')}
  else{s.setAttribute('inert','');s.setAttribute('aria-hidden','true')}
 }
 if(idx===0){$('handoff')?.classList.remove('shown');if(openIntro())$('shell')?.setAttribute('inert','');}
 if(idx!==1){$('handoff')?.classList.remove('shown')}
 if(idx===1){$('handoff')?.classList.add('shown')}
 document.querySelectorAll('[data-thandu-active]').forEach(e=>e.removeAttribute('data-thandu-active'));
 $(stageIds[idx])?.setAttribute('data-thandu-active','');
 if(motionOff)root().classList.add('no-motion');
 // Move keyboard focus into the current chapter; no ancestor may remain focused.
 const firstIds=['primary','memOpen','growFirst','bloomFirst','joyPrimary'];
 const first=$(firstIds[idx]);
 if(first&&!openIntro()&&document.activeElement&&!stageIds.slice(idx,idx+1).some(id=>$(id)?.contains(document.activeElement))){
  requestAnimationFrame(()=>{if(current===idx && first.isConnected)first.focus({preventScroll:true})});
 }
}
function exitOld(i){
 if(i===2){window.THANDU_GROWING?.exit?.()}
 if(i===3){window.THANDU_BLOOM?.exit?.()}
 if(i===4){window.THANDU_JOY?.exit?.()}
 if(i===1){$('handoff')?.classList.remove('shown')}
}
function enterNew(i){
 if(i===1){$('handoff')?.classList.add('shown')}
 if(i===2){window.THANDU_GROWING?.enter?.()}
 if(i===3){window.THANDU_BLOOM?.enter?.()}
 if(i===4){window.THANDU_JOY?.enter?.()}
}
function visit(i,{historyMode='push'}={}){
 i=Math.max(0,Math.min(4,i|0));
 if(navigating)return false;
 if(i===current){keepOne(i);return true}
 navigating=true;
 try{
  closeDialogs();
  exitOld(current);
  enterNew(i);
  keepOne(i);
  if(historyMode==='push')history.pushState({thanduIndex:i},'','#'+keys[i]);
  if(historyMode==='replace')history.replaceState({thanduIndex:i},'','#'+keys[i]);
  window.scrollTo(0,0);
  return true;
 }finally{navigating=false}
}
function openIntro(){return !!$('intro')&&!$('intro').hidden}
function back(){
 const opened=[...document.querySelectorAll('dialog[open]')];
 if(opened.length){try{opened[opened.length-1].close()}catch(e){opened[opened.length-1].removeAttribute('open')}return true}
 if(openIntro()){$('skipIntro')?.click();return true}
 if(current>0){
  // In-app navigation contributes browser history; handle Android's gesture
  // through this function rather than navigating away from the WebView.
  if(history.state && typeof history.state.thanduIndex==='number' && history.length>1){history.back()}
  else visit(current-1,{historyMode:'replace'});
  return true;
 }
 return false;
}
window.THANDU_APP_BACK=back;
window.THANDU_STABILITY=Object.freeze({visit,back,get chapter(){return keys[current]},get index(){return current},get stages(){return stageIds.map((id,i)=>({name:keys[i],visible:i===current,hidden:$(id)?.hasAttribute('inert')}))}});
history.replaceState({thanduIndex:0},'','#arrival');
keepOne(0);
window.addEventListener('popstate',event=>{
 const i=event.state?.thanduIndex;
 if(typeof i==='number'&&i>=0&&i<keys.length)visit(i,{historyMode:'none'});
 else visit(0,{historyMode:'none'});
});
// Intercept only chapter-navigation actions. Individual cinematic scene buttons
// retain their original handlers and creative effects.
document.addEventListener('click',event=>{
 const t=event.target.closest?.('button, [role="button"], .mem-timeline span:last-child');
 if(!t)return;
 const id=t.id;
 let destination=null;
 if(current===0 && (id==='primary'||id==='chapterNext') && window.THANDU_LAB?.state?.revealed)destination=1;
 else if(current===1 && (id==='handoffBack'))destination=0;
 else if(current===1 && (id==='stableMemNext'||t.matches('.mem-to-growing,.mem-timeline span:last-child')))destination=2;
 else if(current===2 && id==='growBack')destination=1;
 else if(current===2 && id==='growContinue')destination=3;
 else if(current===3 && id==='bloomBack')destination=2;
 else if(current===3 && id==='bloomContinue')destination=4;
 else if(current===4 && id==='joyBack')destination=3;
 if(destination!==null){event.preventDefault();event.stopImmediatePropagation();visit(destination);}
},true);
// Permanently visible, accessible next-chapter button on narrow phones and
// tablets alike. No complete-five discovery gate: photographs may be revisited later.
const memFooter=$('handoff')?.querySelector('.mem-bottom');
if(memFooter){
 const b=document.createElement('button');b.type='button';b.id='stableMemNext';b.className='thandu-unified-next';
 b.textContent='Growing Years →';b.setAttribute('aria-label','Continue to chapter three, Growing Years');
 memFooter.appendChild(b);
 const legacy=$('handoff')?.querySelector('.mem-timeline span:last-child');
 if(legacy){legacy.setAttribute('aria-hidden','true');legacy.removeAttribute('role');legacy.removeAttribute('tabindex')}
}
// Joy is the final chapter of THIS checkpoint. Avoid a fake navigation control.
const last=$('joyContinue');if(last){last.textContent='End of five-chapter preview';last.disabled=true;last.setAttribute('aria-label','The next chapter is not yet included in this testing version')}
// One user motion preference across every chapter's original motion controller.
const motionIds=['motionToggle','memMotion','growMotion','bloomMotion','joyMotion'];
let syncingMotion=false;
root().classList.toggle('no-motion',motionOff);
document.addEventListener('click',event=>{
 const target=event.target.closest?.('#'+motionIds.join(',#'));
 if(!target||syncingMotion)return;
 requestAnimationFrame(()=>{
  // Every original chapter controller has already toggled its local flag.
  const desired=target.getAttribute('aria-pressed')==='true';
  syncingMotion=true;
  try{
   for(const id of motionIds){
    if(id===target.id)continue;
    const b=$(id);
    if(b && (b.getAttribute('aria-pressed')==='true')!==desired)b.click();
   }
  }finally{syncingMotion=false}
  motionOff=desired;
  root().classList.toggle('no-motion',desired);
 });
},false);
window.addEventListener('pagehide',()=>{document.querySelectorAll('dialog[open]').forEach(d=>d.close())});
})();
