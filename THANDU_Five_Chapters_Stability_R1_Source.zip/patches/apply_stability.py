#!/usr/bin/env python3
"""Prepare THANDU R1 from the exact five-chapter checkpoint ZIP extraction.
No image recompression, face editing, color grading, or new story content.
"""
import argparse, base64, hashlib, json, re, shutil
from pathlib import Path

def run(project,patch):
    html=project/'app/src/main/assets/index.html'
    src=html.read_text(encoding='utf-8')
    expected='40166a234e0143c777a5db6ade16788879d3879ce8688fd971f1b4186fdee97c'
    digest=hashlib.sha256(src.encode('utf-8')).hexdigest()
    if digest!=expected:
        raise SystemExit('WRONG checkpoint HTML: expected '+expected+' got '+digest)
    media_dir=project/'app/src/main/assets/media'
    media_dir.mkdir(exist_ok=True,parents=True)
    regex=re.compile(r'data:image/(jpeg|webp|png);base64,([A-Za-z0-9+/=]+)')
    contents={}
    count=[0]
    def move(match):
        ext={'jpeg':'.jpg','webp':'.webp','png':'.png'}[match.group(1)]
        data=base64.b64decode(match.group(2),validate=True)
        sha=hashlib.sha256(data).hexdigest()
        name='photo-'+sha[:16]+ext
        target=media_dir/name
        if target.exists() and target.read_bytes()!=data:raise RuntimeError('Hash collision')
        target.write_bytes(data)
        contents[name]={'bytes':len(data),'sha256':sha}
        count[0]+=1
        return 'media/'+name
    src=regex.sub(move,src)
    if count[0]!=31:raise SystemExit(f'Expected 31 authentic image assets, found {count[0]}')
    css=(patch/'stability-layout.css').read_text()
    js=(patch/'stability-controller.js').read_text()
    if '</head>' not in src or '</body>' not in src:raise SystemExit('HTML boundaries missing')
    src=src.replace('</head>','\n<style id="thandu-stability-r1">'+css+'</style>\n</head>',1)
    src=src.replace('</body>','\n<script id="thandu-stability-r1">'+js+'</script>\n</body>',1)
    html.write_text(src,encoding='utf-8')
    shutil.copy2(patch/'MainActivity.java',project/'app/src/main/java/studio/thandu/birthday/MainActivity.java')
    gradle=project/'app/build.gradle'
    s=gradle.read_text().replace('versionCode 1','versionCode 2').replace("versionName '0.5.0-review'","versionName '0.5.1-stability'")
    gradle.write_text(s)
    report={'source_sha256':expected,'output_sha256':hashlib.sha256(src.encode()).hexdigest(),'media_references':count[0],
      'unique_media_files':len(contents),'media_bytes':sum(x['bytes'] for x in contents.values()),'new_html_bytes':len(src.encode()),
      'original_html_bytes':7296898,'media_integrity':contents}
    (project/'STABILITY_BUILD_MANIFEST.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='media_integrity'},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('project');p.add_argument('patch');a=p.parse_args()
    run(Path(a.project),Path(a.patch))
