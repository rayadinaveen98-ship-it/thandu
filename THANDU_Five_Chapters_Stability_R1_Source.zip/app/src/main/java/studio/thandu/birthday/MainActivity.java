package studio.thandu.birthday;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String TAG = "THANDU";
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://appassets.androidplatform.net/";
    private WebView browser;
    private int rendererRecoveries = 0;
    private final OnBackInvokedCallback backCallback = this::handleBack;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        enterFullscreen();
        initBrowser();
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    private static WebResourceResponse notFound() {
        WebResourceResponse response = new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream("Not found".getBytes()));
        response.setStatusCodeAndReasonPhrase(404,"Not Found");
        return response;
    }

    private WebResourceResponse localAsset(Uri uri) {
        if (!"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost())) return null;
        String path = uri.getPath();
        if (path == null) return notFound();
        if ("/".equals(path)) path = "/index.html";
        if (!("/index.html".equals(path) || path.startsWith("/media/"))) return notFound();
        if (path.contains("..") || path.contains("\\") || path.contains("%")) return notFound();
        try {
            String name = path.substring(1);
            InputStream stream = getAssets().open(name);
            String mime = name.endsWith(".html") ? "text/html" :
                    name.endsWith(".webp") ? "image/webp" :
                    name.endsWith(".png") ? "image/png" : "image/jpeg";
            WebResourceResponse response = new WebResourceResponse(mime,
                    name.endsWith(".html") ? "UTF-8" : null,stream);
            Map<String,String> headers = new HashMap<>();
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Cache-Control", "public, max-age=86400");
            response.setResponseHeaders(headers);
            return response;
        } catch(IOException err) {
            Log.e(TAG,"Missing bundled resource: " + path,err);
            return notFound();
        }
    }

    private void initBrowser() {
        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(18,10,30));
        browser.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browser.setVerticalScrollBarEnabled(false);
        browser.setHorizontalScrollBarEnabled(false);
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage msg) {
                String s = msg.message() + " [" + msg.sourceId() + ":" + msg.lineNumber() + "]";
                if (msg.messageLevel()==ConsoleMessage.MessageLevel.ERROR)Log.e(TAG,"JS: "+s);
                else Log.d(TAG,"JS: "+s);
                return true;
            }
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return localAsset(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                return !("https".equals(uri.getScheme()) && HOST.equals(uri.getHost()));
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG,"Web renderer exited. Crashed="+detail.didCrash());
                if(browser!=null){browser.destroy();browser=null;}
                if(rendererRecoveries++<1){initBrowser();}
                else showFailure("Graphics renderer stopped. Reopen THANDU to restart.");
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                Log.i(TAG,"Local story loaded: "+url);
            }
        });
        WebSettings settings=browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        setContentView(browser);
        // Critical change: stream HTML and media through shouldInterceptRequest;
        // no synchronous 7 MB read on the Activity's main/UI thread.
        browser.loadUrl(ORIGIN+"index.html");
    }

    private void showFailure(String message){
        android.widget.TextView text = new android.widget.TextView(this);
        text.setBackgroundColor(Color.rgb(18,10,30));
        text.setTextColor(Color.rgb(255,241,214));
        text.setTextSize(17);
        text.setPadding(38,110,38,38);
        text.setText(message);
        setContentView(text);
    }

    private void enterFullscreen(){
        getWindow().getDecorView().setSystemUiVisibility(
              View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
              View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
              View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
              View.SYSTEM_UI_FLAG_FULLSCREEN |
              View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
              View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);if(focused)enterFullscreen();
    }
    private void handleBack() {
        if(browser==null){finish();return;}
        browser.evaluateJavascript("(function(){try{return !!(window.THANDU_APP_BACK&&window.THANDU_APP_BACK())}catch(e){return false}})()",
          result -> {if(!"true".equals(result)){
              if(browser!=null&&browser.canGoBack())browser.goBack();else finish();
          }});
    }
    @Override public void onBackPressed(){handleBack();}
    @Override public void onPause(){if(browser!=null)browser.onPause();super.onPause();}
    @Override public void onResume(){super.onResume();if(browser!=null)browser.onResume();}
    @Override public void onDestroy(){
        if(Build.VERSION.SDK_INT>=33){
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        if(browser!=null){browser.stopLoading();browser.destroy();browser=null;}
        super.onDestroy();
    }
}
