# THANDU Android — Five-Chapter Stability R1

This package contains the **repaired five-chapter Android WebView project**, not the old unstable checkpoint.

## Included

- Approved Welcome V4 and the five cinematic chapters (First Light, Memories, Growing Years, Bloom, and Joy)
- 27 byte-identical local media files representing all 31 original embedded image references
- A 232 KB HTML shell instead of the earlier 7.3 MB inline-media document
- One authoritative chapter navigation lifecycle, native Android Back support and event handling
- Mobile/landscape overlap and touch corrections, unified motion controls, Android WebView asset streaming and renderer diagnostics
- `STABILITY_REPORT.md`: repair details and browser test matrix
- `STABILITY_BUILD_MANIFEST.json`: verifiable source/image hashes

## Produce APK

Upload this ZIP as `THANDU_Five_Chapters_Stability_R1_Source.zip` to branch `android-stability-r1` of `rayadinaveen98-ship-it/thandu`, then open the GitHub Actions run named **THANDU Android — Stability R1**. It will verify the project and build a debug-signed installable APK. Keep this branch separate from main.

## Verification and limitations

Chromium integration tests passed at 390×844 (25/25), 320×640 (25/25), 800×360 (26/26) and 1440×900 (25/25). The APK **has not yet been rebuilt or physically tested on your Android phone**. Native WebView/performance and manufacturer-specific behavior must be verified after building.

No photographs, human faces, or approved original artwork were regenerated or retouched. This package does not include Chapters 6–8, which remain future milestones.
