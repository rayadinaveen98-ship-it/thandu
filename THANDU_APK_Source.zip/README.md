# THANDU — 5-Chapter Android APK Checkpoint

**Package source:** latest owner-reviewed five-chapter standalone HTML, unmodified, copied to `app/src/main/assets/index.html`.
**Original HTML SHA-256:** `40166a234e0143c777a5db6ade16788879d3879ce8688fd971f1b4186fdee97c`.

This is a **real Android native-shell project**, not a renamed HTML file or a shortcut to the older live Vercel website. It loads the already-tested HTML inside a full-screen Android WebView. All illustration assets, original portraits, CSS, and JavaScript remain embedded. **No internet permission is requested** and no app data is uploaded by the shell.

## What is included

- Welcome V4 — approved candle-first introduction.
- First Light — approved bird-to-photo reveal.
- Memories — approved five interactive memories.
- Growing Years — approved discovery chapter.
- A World in Bloom — approved floral reveals.
- The Joy She Brings V1 — latest candidate; user review may still be needed.
- The last chapters remain intentionally not implemented in this checkpoint.

## Build an installable debug APK

### Android Studio

1. Install Android Studio with the Android SDK for API 35 and JDK 17.
2. Open the root folder of this project (`THANDU_APK_Checkpoint_1`).
3. Let Android Studio sync Gradle and download missing SDK/Gradle components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Use `app/build/outputs/apk/debug/app-debug.apk` to install on an Android phone (the debug variant has package ID `studio.thandu.birthday.review`).

### GitHub Actions (zero local Android setup)

Upload this project's contents to a GitHub repository, including the **7 MB `app/src/main/assets/index.html`** file. Under **Actions**, run **THANDU Android APK checkpoint** using *Run workflow*. When the build succeeds, download the artifact called **THANDU-five-chapter-android-debug-APK**. This artifact contains a correctly compiled and Android-debug-signed APK, not an HTML file.

### Local terminal (if Android SDK + Gradle installed)

`gradle :app:assembleDebug --no-daemon`

## Privacy

The APK itself contains personal photographs. Anyone with the APK can extract/copy those photographs. Keep the testing APK private unless everyone pictured has approved distribution. This project does not have Internet permission.

## Installation notes

- Requires Android 8.0 (API 26) or later.
- This is a development testing package, **not Play Store release-signed**.
- Does not automatically update when the webapp changes. Rebuild after approving future chapters.
- No modifications to original user photographs or approved HTML.
- The project is prepared but **not compiled or phone-installed in the current tool environment**; Android SDK/Gradle were unavailable here. Compile via Android Studio or GitHub Actions.
